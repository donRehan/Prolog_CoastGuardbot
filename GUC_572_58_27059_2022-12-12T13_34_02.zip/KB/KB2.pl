grid(4,4).
agent_loc(0,2).
ships_loc([[1,2], [3,2]]).
station(1,1).
capacity(2).
