These are two examples of a possible knowledge base that you can test your code with.
You consult a knowledge base by putting the following line at the beginning of your code:
:- include('KB.pl').
or
:- include('KB2.pl').